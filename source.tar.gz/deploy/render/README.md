# No-card free deployment (not deployed yet)

Use a **Free Web Service** on Render, Dockerfile `deploy/render/Dockerfile`, repository root context.
This runs Next, FastAPI and a Wasmtime sandbox in one service; only Next's port is public.
Keep the original `render.yaml` out of this flow: its upstream plans are paid.

Required runtime settings, entered privately in Render:
- `DATABASE_URL`: a Neon **Free** PostgreSQL connection string with SSL.
- `FEATHERLESS_API_KEY`: the existing hackathon key, never committed.

Python is 3.15 in WASI for this deployment, 3.11 in the local Docker runner.
Expected answers are never mounted into the guest. Only its own code/arguments and the
Python distribution are readable. No host environment or network capabilities are granted.
Memory, fuel, output size and wall-clock execution are bounded; executions are serialized.

Limits: Render sleeps after 15 minutes idle, wakes on requests, and provides 750 free hours/month.
No payment method means service suspension rather than overage charges. Neon Free has usage
limits. Featherless credits can expire/run out independently. Generation is an in-process job;
restarts during generation can interrupt it. This remains a small hackathon demo.

Status: native sandbox tests passed across all nine topic/tier pairs plus isolation probes.
Linux image/resource validation and cloud publication still required. This is not a deployment URL.
