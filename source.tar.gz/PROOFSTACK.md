# ProofStack — portfolio-driven assessment

A working hackathon prototype built on [SignalLoop](https://github.com/signalloop-ai/signalloop)
(commit `31b2507`, Apache 2.0). Original authors: Sreenivas Makam and Ritesh Dhoot.
Original LICENSE, NOTICE, AUTHORS and THIRD_PARTY_NOTICES are retained. Upstream's README
and historical feature claims are not a statement of this fork's verification.

## Open it

http://127.0.0.1:3001

The current session has the API on 8001, worker on 9001, and PostgreSQL on 55432.
To restart after stopping the current servers, run `./scripts/start-local.sh` from this folder.
Requires Docker Desktop, Node 22+, and Python 3.11+ (uv can install API dependencies).
Do not run a second copy over already-running servers.

## Configuration

Root `.env` is ignored by Git and contains server-only secrets. Never use NEXT_PUBLIC for keys.

```
FEATHERLESS_API_KEY=<your key>
FEATHERLESS_MODEL=Qwen/Qwen2.5-7B-Instruct
FEATHERLESS_GENERATION_MODEL=Qwen/Qwen3-Coder-30B-A3B-Instruct
DATABASE_URL=postgresql+psycopg://postgres:proofstack-local@127.0.0.1:55432/proofstack
EXECUTION_WORKER_URL=http://127.0.0.1:9001
CORS_ORIGINS=http://127.0.0.1:3001,http://localhost:3001
REPORT_ADVISORY_ENABLED=false
```

`apps/web/.env.local`: `NEXT_PUBLIC_API_BASE_URL=http://127.0.0.1:8001`.
Restart the API after changing secrets. The upstream employer/admin portal remains Clerk-protected;
this candidate-first prototype doesn't need a Clerk account.

## Demo in five minutes

1. Open the homepage; use the sample, edit the form, or upload structured JSON.
2. Create the assessment. The timer has not started while generation/validation runs.
3. Check the three release cards. Generated tasks are labeled; rejected AI tasks retry once with a 500-token portfolio-framing request around a verified base,
   then use explicitly labeled, validated templates.
4. Start the shared 60-minute assessment. Every tier has a project task and a declared-topic DSA task.
5. Edit files in Monaco, run public checks, show “Why this question?”, and demonstrate autosave.
6. Novice has no AI (enforced by API). In Adept/Master, ask about one observed failure.
7. Submit all tiers. Show hidden-test results, the 80/20 score breakdown, per-tier elapsed time,
   hint use, distinct tested revisions, evidence timeline, and downloaded JSON report.

## What is implemented

- JSON/schema validation, Python portfolio support, Backend/Web/ML/Security contexts.
- Arrays, hash maps, and strings; topics rotate across the candidate's declared list.
- Featherless-authored project contract, starter, reference, and test cases.
- Curated topic-bounded DSA exercises; three difficulty tiers, multi-file work at higher tiers.
- Reference must pass all cases. Both project and DSA starter must fail at least one case.
- Shared server-side deadline, saved snapshots, revision conflict protection, immutable submission.
- Docker execution: no network, nonroot, read-only workspace, resource limits, timeout cleanup.
- Expected answers remain in the worker controller, outside the candidate container.
- Deterministic grading and AI efficiency, contextual hints, downloadable evidence report.

## Scoring

80 points for correctness: Novice 20%, Adept 35%, Master 45% within that component.
20 points from average AI efficiency in Adept/Master. With no hints, efficiency equals correctness.
With hints: correctness × min(1, 2 × average public-test gain per hint +
0.25 × min(distinct tested code versions, 3)/3).
Repeated test runs of the same code do not inflate distinct-version counts. No LLM assigns correctness.
Time per tier is elapsed time while that tier is selected, including idle time. On expiry only saved code counts.

## Verification

```
cd apps/api
FEATHERLESS_API_KEY='' .venv/bin/python -m pytest tests/test_portfolio.py tests/test_featherless_provider.py tests/test_ai_provider.py tests/test_ai_policy.py -q
# From repo root with API, worker and DB running:
PYTHONPATH=apps/api apps/api/.venv/bin/python scripts/verify_portfolio.py
# From apps/web:
npm run build
```

## Practical limits

This is a local hackathon prototype, not a production hiring service. Python only; three DSA topics.
Project challenges are JSON-in/JSON-out Python features, not full browser/ML training deployments.
AI generation can fall back to templates, which have a generic event-processing context.
DSA difficulty is curated; arbitrary claim topics and automatic difficulty changes are not supported.
A passing reference proves consistency with tests, not that AI-generated tests fully capture intent.
Performance is checked on bounded inputs and timeouts, not formally proven asymptotic complexity.
AI guardrails are tested but not a guarantee against every extraction attempt.
Generated sessions use in-process background jobs; don't restart the API during generation.
Session URLs are bearer credentials. Anyone with the link can access/edit that session.
Services bind to localhost. Public deployment needs auth/quotas, durable jobs, operational monitoring,
and isolation review. Upstream worker endpoints are retained; don't expose port 9001 publicly.

## Our contribution

Portfolio intake and grouping, topic-bounded DSA, task authoring/release gates, the external-answer
function evaluator, shared timebox, candidate UI, score formula and report, and Featherless integration.
SignalLoop provides the Next/Monaco/FastAPI/Postgres foundation, model architecture, Docker runtime,
and existing candidate-assistant policy/provider code. Cite both in your submission and check reuse rules.

## AI usage limits

At most 3 full generation calls (4,500 output tokens each) and 3 small personalization retries
(500 output tokens each) per assessment. No AI calls while polling progress, editing, saving,
running tests, or grading. Up to 12 hints per assisted tier, each usually 2 calls capped at
80 classifier and 350 response tokens. Provider credits are finite; the app does not read your
account balance. Remaining testing after the cost check uses mocks/local Docker.
