import copy
import time
import pytest
from fastapi import HTTPException
from signalloop_api.portfolio import Portfolio, CodePayload, apply_code, ensure_active, safe_view, build_report
from signalloop_api.portfolio_tasks import template_task

P={'name':'Alex','domain':'Backend','projects':[{'name':'Campus','tech_stack':['Python']}],'skills':['Python'],'dsa_topics':['arrays']}

def test_topics_are_bounded():
    with pytest.raises(ValueError): Portfolio(**(P|{'dsa_topics':['graphs']}))
    assert Portfolio(**(P|{'dsa_topics':['Hash Maps']})).dsa_topics==['hash_maps']

def test_deadline_and_status_enforced():
    for s in [{'status':'ready'},{'status':'completed'},{'status':'active','deadline':time.time()-1}]:
        with pytest.raises(HTTPException): ensure_active(s)

def test_stale_revision_and_unapproved_file_rejected():
    t={'starter':{'task_api/main.py':''},'revision':2}
    with pytest.raises(HTTPException): apply_code(t,CodePayload(files=t['starter'],revision=1))
    with pytest.raises(HTTPException): apply_code(t,CodePayload(files={'runner.py':''},revision=2))

def test_no_hidden_expected_or_reference_in_candidate_view():
    class Row: token='test'
    t=template_task(P,0)
    out=safe_view(Row(),{'tasks':[t]})
    assert 'reference' not in out['tasks'][0]
    assert 'cases' not in out['tasks'][0]
    assert all(c['public'] for c in out['tasks'][0]['examples'])

def test_score_cannot_exceed_100_and_repeated_runs_do_not_inflate(monkeypatch):
    tasks=[]
    for i in range(3):
        t=template_task(P,i);t.update(files=t['reference'],runs=[{'snapshot':'same','passed':4,'total':4,'at':time.time()}]*10,hints=[])
        tasks.append(t)
    monkeypatch.setattr('signalloop_api.portfolio.evaluate',lambda f,c:{'passed':len(c),'total':len(c),'status':'completed','duration_ms':10,'checks':[{'name':x['name'],'passed':True} for x in c]})
    report=build_report({'tasks':tasks,'started_at':time.time()-10,'deadline':time.time()+100})
    assert report['score']==100
    assert all(t['distinct_tested_versions']==1 for t in report['tasks'])

def test_hint_context_excludes_private_answers_and_maps_roles(monkeypatch):
    from signalloop_api import portfolio
    from signalloop_api.ai_policy import AIDecision
    t=template_task(P,1)
    t.update(files=t['starter'],hints=[],runs=[],chat=[{'role':'user','message':'What is an accumulator?'}])
    s={'status':'active','deadline':time.time()+100,'tasks':[{},t],'events':[]}
    captured={}
    class Provider:
        def evaluate(self,message,context,recent_messages,**kwargs):
            captured.update(kwargs)
            return AIDecision(allowed=True,policy_tags=[],message='Trace one event through your accumulator.')
    monkeypatch.setattr(portfolio,'load',lambda db,token:(object(),s))
    monkeypatch.setattr(portfolio,'persist',lambda *args:None)
    monkeypatch.setattr(portfolio,'get_ai_provider',lambda:Provider())
    result=portfolio.hint('test',1,portfolio.HintPayload(message='How do I trace a single value?'),None)
    assert result['allowed']
    assert captured['recent_turns'][0][0]=='candidate'
    assert captured['workspace_files']['CHALLENGE.md'].startswith(t['statement'])
    assert set(captured['workspace_files'])==set(t['starter'])|{'CHALLENGE.md'}
    assert captured['workspace_files']['task_api/helpers.py']!=t['reference']['task_api/helpers.py']

def test_grounded_retry_preserves_verified_contract_and_private_artifacts(monkeypatch):
    import httpx
    from signalloop_api import portfolio_tasks
    monkeypatch.setattr(portfolio_tasks.settings,'featherless_api_key','test-only')
    captured={}
    def post(url,**kwargs):
        captured.update(kwargs['json'])
        return httpx.Response(200,json={'choices':[{'message':{'content':'{"title":"Campus event ownership","why":"Practice aggregation used in your project."}'}}]},request=httpx.Request('POST',url))
    monkeypatch.setattr(portfolio_tasks.httpx,'post',post)
    result=portfolio_tasks.personalize_task(P,2,grounded=True)
    base=template_task(P,2)
    for field in ('starter','reference','cases','statement','dsa_statement'): assert result[field]==base[field]
    assert result['source']=='Featherless personalized'
    assert captured['max_tokens']==500


def test_question_runs_keep_other_question_evidence_without_running_it(monkeypatch):
    from signalloop_api import portfolio
    t=template_task(P,1)
    t.update(files=dict(t['starter']),runs=[],revision=0)
    s={'status':'active','deadline':time.time()+100,'tasks':[t],'events':[]}
    evaluated=[]
    def evaluate(files,cases):
        evaluated.append(cases)
        return {'passed':len(cases),'total':len(cases),'checks':[{'name':c['name'],'passed':True,'actual':c['expected']} for c in cases],'duration_ms':1,'status':'completed'}
    monkeypatch.setattr(portfolio,'load',lambda *args:(object(),s))
    monkeypatch.setattr(portfolio,'persist',lambda *args:None)
    monkeypatch.setattr(portfolio,'evaluate',evaluate)
    first=portfolio.run('test',0,portfolio.RunPayload(files=dict(t['files']),revision=0,question='project'),None)['result']
    assert first['passed']==2 and first['total']==4
    assert all(not c['module'].endswith('dsa') for c in evaluated[-1])
    edited=dict(t['files']);edited['task_api/dsa.py']+='\n# edited'
    second=portfolio.run('test',0,portfolio.RunPayload(files=edited,revision=1,question='dsa'),None)['result']
    assert second['passed']==4 and second['total']==4
    assert all(c['module'].endswith('dsa') and c['public'] for c in evaluated[-1])
    edited=dict(t['files']);edited['task_api/main.py']+='\n# changed project'
    third=portfolio.run('test',0,portfolio.RunPayload(files=edited,revision=2,question='dsa'),None)['result']
    assert third['passed']==2 and third['total']==4


@pytest.mark.parametrize('change',['none','comments','docstring','project','dsa'])
def test_starter_passes_do_not_earn_marks(monkeypatch,change):
    tasks=[]
    for i in range(3):
        t=template_task(P,i)
        files=dict(t['starter'])
        if change=='comments': files={f:v+'\n# comment only\n' for f,v in files.items()}
        if change=='docstring': files={f:'"""Only documentation."""\n'+v for f,v in files.items()}
        if change in ('project','dsa'):
            files.update({f:v for f,v in t['reference'].items() if (f.endswith('/dsa.py'))==(change=='dsa')})
        t.update(files=files,runs=[],hints=[]);tasks.append(t)
    def evaluate(files,cases):
        return {'passed':len(cases),'total':len(cases),'checks':[{'name':c['name'],'passed':True} for c in cases],'status':'completed','duration_ms':1}
    monkeypatch.setattr('signalloop_api.portfolio.evaluate',evaluate)
    state={'tasks':tasks,'started_at':time.time()-10,'deadline':time.time()+100}
    report=build_report(state)
    if change in ('none','comments','docstring'):
        assert report['score']==report['coding_points']==report['ai_points']==0
    else:
        for t,graded in zip(tasks,report['tasks']):
            assert graded['passed']==sum((c['module'].endswith('dsa'))==(change=='dsa') for c in t['cases'])
    # Recalculating old persisted results remains deterministic and does not execute code.
    monkeypatch.setattr('signalloop_api.portfolio.evaluate',lambda *args:pytest.fail('Unexpected execution'))
    assert build_report(state,stored_results=True)['score']==report['score']
