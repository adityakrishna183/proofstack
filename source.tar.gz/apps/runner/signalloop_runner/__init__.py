"""Fargate assessment runner package."""
