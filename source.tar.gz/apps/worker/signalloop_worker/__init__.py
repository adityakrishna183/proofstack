"""SignalLoop execution worker package."""
